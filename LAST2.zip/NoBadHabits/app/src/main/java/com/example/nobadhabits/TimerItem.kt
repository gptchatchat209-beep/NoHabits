package com.example.nobadhabits

import org.json.JSONArray
import org.json.JSONObject

data class TimerItem(
    var taskName: String,
    var page: Int = 0, // 0 = Цели, 1 = Избавления
    var startTime: Long,
    var elapsedTime: Long = 0L,
    var isRunning: Boolean = false,
    var duration: Long = 24 * 60 * 60 * 1000L,
    var milestones: MutableList<Long> = mutableListOf(
        1 * 60 * 60 * 1000L,
        3 * 60 * 60 * 1000L,
        10 * 60 * 60 * 1000L,
        24 * 60 * 60 * 1000L
    ),
    var currentMilestoneIndex: Int = 0,
    var completedCycles: Int = 0,
    var lastProcessedCycle: Int = -1
) {

    // ✅ ВОТ ОНО: текущее время "на лету" (ничего не ломаем, просто считаем)
    fun getCurrentElapsed(now: Long = System.currentTimeMillis()): Long {
        return if (isRunning) elapsedTime + (now - startTime) else elapsedTime
    }

    // Текущая задача (время в миллисекундах)
    val currentMilestone: Long
        get() = if (currentMilestoneIndex < milestones.size) {
            milestones[currentMilestoneIndex]
        } else {
            24 * 60 * 60 * 1000L
        }

    // ✅ Проверяем milestone по ТЕКУЩЕМУ времени
    fun isMilestoneAchieved(now: Long = System.currentTimeMillis()): Boolean {
        val cur = getCurrentElapsed(now)

        if (currentMilestoneIndex < milestones.size) {
            return cur >= currentMilestone
        } else {
            val cycleDuration = 24 * 60 * 60 * 1000L
            val expectedCycles = (cur / cycleDuration).toInt()
            return expectedCycles > lastProcessedCycle
        }
    }

    fun moveToNextMilestone(now: Long = System.currentTimeMillis()) {
        val cur = getCurrentElapsed(now)

        if (currentMilestoneIndex < milestones.size - 1) {
            currentMilestoneIndex++
        } else {
            val cycleDuration = 24 * 60 * 60 * 1000L
            completedCycles = (cur / cycleDuration).toInt()
            lastProcessedCycle = completedCycles
        }
    }

    // ✅ Прогресс milestone по ТЕКУЩЕМУ времени
    val milestoneProgress: Float
        get() {
            val cur = getCurrentElapsed()
            val cycleDuration = 24 * 60 * 60 * 1000L

            val effectiveTime = if (currentMilestoneIndex >= milestones.size) {
                cur % cycleDuration
            } else {
                cur
            }

            val progress = effectiveTime.toFloat() / currentMilestone.toFloat()
            return progress.coerceIn(0f, 1f)
        }

    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("taskName", taskName)
        json.put("page", page)
        json.put("startTime", startTime)
        json.put("elapsedTime", elapsedTime)
        json.put("isRunning", isRunning)
        json.put("duration", duration)
        json.put("currentMilestoneIndex", currentMilestoneIndex)
        json.put("completedCycles", completedCycles)
        json.put("lastProcessedCycle", lastProcessedCycle)

        val milestonesArray = JSONArray()
        milestones.forEach { milestonesArray.put(it) }
        json.put("milestones", milestonesArray)

        return json
    }

    companion object {
        fun fromJson(json: JSONObject): TimerItem {
            val milestonesArray = json.optJSONArray("milestones") ?: JSONArray()
            val milestones = mutableListOf<Long>()
            for (i in 0 until milestonesArray.length()) {
                milestones.add(milestonesArray.getLong(i))
            }

            return TimerItem(
                taskName = json.getString("taskName"),
                page = json.optInt("page", 0),
                startTime = json.getLong("startTime"),
                elapsedTime = json.getLong("elapsedTime"),
                isRunning = json.getBoolean("isRunning"),
                duration = json.optLong("duration", 24 * 60 * 60 * 1000L),
                milestones = if (milestones.isEmpty()) mutableListOf(
                    1 * 60 * 60 * 1000L,
                    3 * 60 * 60 * 1000L,
                    10 * 60 * 60 * 1000L,
                    24 * 60 * 60 * 1000L
                ) else milestones,
                currentMilestoneIndex = json.optInt("currentMilestoneIndex", 0),
                completedCycles = json.optInt("completedCycles", 0),
                lastProcessedCycle = json.optInt("lastProcessedCycle", -1)
            )
        }
    }

    // ❌ ВАЖНО: tick() удалили, он тебе больше НЕ нужен и делал неверно
}
