package com.example.nobadhabits

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TimerAdapter(
    private val timers: MutableList<TimerItem>,
    private val onItemClick: (TimerItem) -> Unit,
    private val onDeleteClick: (TimerItem) -> Unit
) : RecyclerView.Adapter<TimerAdapter.TimerViewHolder>() {

    companion object {
        const val PAYLOAD_TICK = "TICK"
    }

    inner class TimerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val taskName: TextView = itemView.findViewById(R.id.taskName)
        private val timerText: TextView = itemView.findViewById(R.id.timerText)
        private val progressArc: ProgressArcView = itemView.findViewById(R.id.progressView)
        private val deleteIcon: ImageView = itemView.findViewById(R.id.deleteIcon)

        // ✅ новая картинка для целей
        private val goalImage: ImageView? = itemView.findViewById(R.id.goalImage)

        fun bind(timer: TimerItem) {
            taskName.text = timer.taskName

            // первичная отрисовка
            updateTick(timer)

            deleteIcon.setOnClickListener { onDeleteClick(timer) }
            itemView.setOnClickListener { onItemClick(timer) }
        }

        fun updateTick(timer: TimerItem) {
            val current = timer.getCurrentElapsed()

            if (timer.page == 0) {
                // ===== ЦЕЛИ =====
                val day = (current / (24 * 60 * 60 * 1000L)).toInt() + 1
                timerText.text = "День $day"

                // прогресс скрываем
                progressArc.visibility = View.GONE

                // картинка только для "Спорт"
                if (timer.taskName.equals("Спорт", ignoreCase = true)) {
                    goalImage?.visibility = View.VISIBLE
                    goalImage?.setImageResource(R.drawable.sport)
                } else {
                    goalImage?.visibility = View.GONE
                }

            } else {
                // ===== ИЗБАВЛЕНИЯ =====
                timerText.text = formatTime(current)

                progressArc.visibility = View.VISIBLE
                progressArc.setProgress(timer.milestoneProgress)

                // в избавлениях картинка скрыта
                goalImage?.visibility = View.GONE
            }

            // корзина
            deleteIcon.visibility = if (timer.isRunning) View.INVISIBLE else View.VISIBLE
        }

        private fun formatTime(millis: Long): String {
            val seconds = (millis / 1000) % 60
            val minutes = (millis / (1000 * 60)) % 60
            val hours = (millis / (1000 * 60 * 60)) % 24
            val days = millis / (1000 * 60 * 60 * 24)
            return String.format("%dд. %02dч %02dм %02dс", days, hours, minutes, seconds)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimerViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_timer, parent, false)
        return TimerViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimerViewHolder, position: Int) {
        holder.bind(timers[position])
    }

    override fun onBindViewHolder(holder: TimerViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            holder.updateTick(timers[position])
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    override fun getItemCount(): Int = timers.size

    fun cleanup() {
        // ничего не нужно
    }
}
