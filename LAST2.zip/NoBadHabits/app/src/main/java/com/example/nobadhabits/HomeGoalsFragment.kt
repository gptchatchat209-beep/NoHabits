package com.example.nobadhabits

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView

class HomeGoalsFragment : Fragment(R.layout.fragment_home_goals) {

    companion object {
        private const val ARG_PREVIEW = "ARG_PREVIEW"

        fun newInstance(preview: Boolean): HomeGoalsFragment {
            return HomeGoalsFragment().apply {
                arguments = Bundle().apply {
                    putBoolean(ARG_PREVIEW, preview)
                }
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val isPreview = arguments?.getBoolean(ARG_PREVIEW) ?: false

        val title = view.findViewById<TextView>(R.id.pageTitle)
        title.visibility = if (isPreview) View.GONE else View.VISIBLE


        val rv = view.findViewById<RecyclerView>(R.id.timersRecyclerView)
        rv.layoutManager = LinearLayoutManager(requireContext())

        if (isPreview) {
            // ✅ Показываем только page = 0 (Цели)
            val previewList = MainActivity.timerListStatic.filter { it.page == 0 }.toMutableList()

            val previewAdapter = TimerAdapter(
                timers = previewList,
                onItemClick = { },
                onDeleteClick = { }
            )
            rv.adapter = previewAdapter
        } else {
            // ✅ В обычном режиме — свой адаптер страницы Goals
            rv.adapter = (activity as? MainActivity)?.getGoalsAdapter()
        }
    }
}
