package com.example.nobadhabits

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Настройка списка с разделами настроек
        val settingsListView = findViewById<ListView>(R.id.settingsList)

        val settingsItems = listOf(
            "🎨 Выбор темы",
            "🔔 Уведомления",
            "🌍 Язык интерфейса",
            "📱 Виджет и экран блокировки",
            "ℹ️ О приложении"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, settingsItems)
        settingsListView.adapter = adapter

        settingsListView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> {} // Theme settings
                1 -> {} // Notifications
                2 -> showLanguageDialog() // Language
                3 -> {} // Widget
                4 -> {} // About app
            }
        }

        // Нижняя навигация
        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottomNavigation)
        // Убрали selectedItemId, так как Settings не в навигации
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                R.id.nav_ranking -> {
                    val intent = Intent(this, RankingActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                R.id.nav_rewards -> {
                    val intent = Intent(this, RewardsActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                R.id.nav_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                else -> false
            }
        }
    }

    private fun showLanguageDialog() {
        val languages = arrayOf("Английский", "Русский", "Польский", "Украинский")
        AlertDialog.Builder(this)
            .setTitle("Выберите язык")
            .setItems(languages) { _, which ->
                // Пока ничего не делаем
            }
            .setNegativeButton("Отмена") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Убрали selectedItemId
    }

    override fun onBackPressed() {
        val intent = Intent(this, ProfileActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        super.onBackPressed()
    }
}