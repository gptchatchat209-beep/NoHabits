package com.example.nobadhabits

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TemplateAdapter(
    private val items: List<TemplateItem>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<TemplateAdapter.VH>() {

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val img: ImageView = itemView.findViewById(R.id.templateImage)
        private val title: TextView = itemView.findViewById(R.id.templateTitle)
        private val subtitle: TextView = itemView.findViewById(R.id.templateSubtitle)

        fun bind(item: TemplateItem) {
            img.setImageResource(item.imageRes)
            title.text = item.title
            subtitle.text = item.subtitle

            itemView.setOnClickListener { onClick(item.title) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_template, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size
}
