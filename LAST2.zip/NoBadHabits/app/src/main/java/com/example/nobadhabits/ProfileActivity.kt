package com.example.nobadhabits

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProfileActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var avatarImage: ImageView
    private lateinit var nicknameText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Инициализация SharedPreferences
        prefs = getSharedPreferences("NoBadHabitsPrefs", MODE_PRIVATE)
        avatarImage = findViewById(R.id.avatarImage)
        nicknameText = findViewById(R.id.nicknameText)

        // Загрузка ника и аватара
        val nickname = prefs.getString("nickname", "Гость") ?: "Гость"
        nicknameText.text = nickname
        val avatarResId = prefs.getInt("avatarResId", R.drawable.avatar_cat)
        avatarImage.setImageResource(avatarResId)

        // Кнопка редактирования имени
        findViewById<Button>(R.id.editNicknameButton).setOnClickListener {
            showEditNicknameDialog()
        }

        // Кнопка общих настроек
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Выбор аватара
        avatarImage.setOnClickListener {
            showAvatarDialog()
        }

        // Настройка BottomNavigationView
        val bottomNavigation: BottomNavigationView = findViewById(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_profile
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                R.id.nav_ranking -> {
                    val intent = Intent(this, RankingActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                R.id.nav_rewards -> {
                    val intent = Intent(this, RewardsActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    }
                    startActivity(intent)
                    overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
                    true
                }
                R.id.nav_profile -> true
                else -> false
            }
        }
    }

    private fun showEditNicknameDialog() {
        val editText = EditText(this)
        editText.setText(nicknameText.text)
        AlertDialog.Builder(this)
            .setTitle("Редактировать имя")
            .setView(editText)
            .setPositiveButton("Сохранить") { _, _ ->
                val newNickname = editText.text.toString().trim().ifEmpty { "Гость" }
                nicknameText.text = newNickname
                prefs.edit().putString("nickname", newNickname).apply()
            }
            .setNegativeButton("Отмена") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showAvatarDialog() {
        val avatars = arrayOf("Кот", "Собака", "Медведь","Коала")
        val avatarResIds = intArrayOf(
            R.drawable.avatar_cat,
            R.drawable.avatar_dog,
            R.drawable.bird,
            R.drawable.koala
        )
        AlertDialog.Builder(this)
            .setTitle("Выберите аватар")
            .setItems(avatars) { _, which ->
                avatarImage.setImageResource(avatarResIds[which])
                prefs.edit().putInt("avatarResId", avatarResIds[which]).apply()
            }
            .setNegativeButton("Отмена") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        findViewById<BottomNavigationView>(R.id.bottomNavigation).selectedItemId = R.id.nav_profile
    }

    override fun onBackPressed() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
        super.onBackPressed()
    }
}