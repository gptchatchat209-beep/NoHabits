package com.example.nobadhabits

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter

class HomePagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    override fun getItemCount(): Int = 2

    override fun createFragment(position: Int): Fragment {
        return if (position == 0) {
            HomeGoalsFragment.newInstance(preview = false)
        } else {
            HomeRemoveFragment.newInstance(preview = false)
        }
    }
}
