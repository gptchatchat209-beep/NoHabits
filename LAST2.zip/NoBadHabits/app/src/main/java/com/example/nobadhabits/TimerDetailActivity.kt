package com.example.nobadhabits

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CalendarView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TimerDetailActivity : AppCompatActivity() {

    private lateinit var bigTimerText: TextView
    private lateinit var taskTitle: TextView
    private lateinit var stopButton: Button
    private lateinit var milestoneText: TextView
    private lateinit var calendarView: CalendarView

    private val handler = Handler(Looper.getMainLooper())

    private val prefsName = "timer_prefs"

    private lateinit var taskName: String
    private var startTime: Long = 0L
    private var elapsedTime: Long = 0L
    private var isRunning: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer_detail)

        bigTimerText = findViewById(R.id.bigTimerText)
        taskTitle = findViewById(R.id.taskTitle)
        stopButton = findViewById(R.id.stopButton)
        milestoneText = findViewById(R.id.milestoneText)
        calendarView = findViewById(R.id.calendarView)

        taskName = intent.getStringExtra("TASK_NAME") ?: "Без названия"
        startTime = intent.getLongExtra("START_TIME", System.currentTimeMillis())
        elapsedTime = intent.getLongExtra("ELAPSED_TIME", 0L)
        isRunning = intent.getBooleanExtra("IS_RUNNING", true)


        taskTitle.text = taskName
        calendarView.setDate(System.currentTimeMillis(), false, true)

        stopButton.isEnabled = isRunning
        stopButton.text = if (isRunning) "Сдаться" else "Остановлено"

        startTimerUpdates()

        stopButton.setOnClickListener {
            if (isRunning) {
                elapsedTime += System.currentTimeMillis() - startTime
                isRunning = false
                stopButton.isEnabled = false
                stopButton.text = "Остановлено"

                clearPrefs()
                sendResultBack()
            }
        }
    }

    private fun startTimerUpdates() {
        handler.post(object : Runnable {
            override fun run() {
                val currentTime = if (isRunning) {
                    elapsedTime + (System.currentTimeMillis() - startTime)
                } else {
                    elapsedTime
                }
                bigTimerText.text = formatTime(currentTime)
                handler.postDelayed(this, 1000)
            }
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        sendResultBack()
        super.onBackPressed()
    }


    private fun sendResultBack() {
        val now = System.currentTimeMillis()

        // ✅ если таймер работает — сначала "докрутим" elapsedTime до текущего момента
        if (isRunning) {
            elapsedTime += now - startTime
            startTime = now
        }

        val resultIntent = Intent().apply {
            putExtra("TASK_NAME", taskName)
            putExtra("START_TIME", startTime)
            putExtra("ELAPSED_TIME", elapsedTime)
            putExtra("IS_RUNNING", isRunning)
        }
        setResult(RESULT_OK, resultIntent)
    }


    private fun clearPrefs() {
        getSharedPreferences(prefsName, MODE_PRIVATE)
            .edit()
            .clear()
            .apply()
    }

    @SuppressLint("DefaultLocale")
    private fun formatTime(millis: Long): String {
        val seconds = (millis / 1000) % 60
        val minutes = (millis / (1000 * 60)) % 60
        val hours = (millis / (1000 * 60 * 60)) % 24
        val days = millis / (1000 * 60 * 60 * 24)
        return String.format("%dд %02dч %02dм %02dс", days, hours, minutes, seconds)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
