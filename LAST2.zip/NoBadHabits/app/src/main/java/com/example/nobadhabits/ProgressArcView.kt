package com.example.nobadhabits

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat

class ProgressArcView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var progress: Float = 0f  // от 0.0 до 1.0

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, android.R.color.darker_gray)
        style = Paint.Style.STROKE
        strokeWidth = 20f
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, android.R.color.holo_red_dark)
        style = Paint.Style.STROKE
        strokeWidth = 20f
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER // Центрируем текст
    }

    private val rect = RectF()

    init {
        // Читаем атрибуты из XML
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.ProgressArcView, defStyleAttr, 0)
        progress = typedArray.getFloat(R.styleable.ProgressArcView_progress, 0f)
        backgroundPaint.strokeWidth = typedArray.getDimension(R.styleable.ProgressArcView_progressWidth, 20f)
        progressPaint.strokeWidth = typedArray.getDimension(R.styleable.ProgressArcView_progressWidth, 20f)
        textPaint.textSize = typedArray.getDimension(R.styleable.ProgressArcView_textSize, 60f) // Размер текста
        textPaint.color = typedArray.getColor(R.styleable.ProgressArcView_textColor, ContextCompat.getColor(context, android.R.color.holo_red_dark)) // Красный цвет
        typedArray.recycle()
    }

    fun setProgress(progress: Float) {
        this.progress = progress.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val padding = 15f
        val size = width.coerceAtMost(height)
        rect.set(
            padding,
            padding,
            size - padding,
            size - padding
        )

        // Рисуем фон полукруга (240 градусов)
        canvas.drawArc(rect, 150f, 240f, false, backgroundPaint)

        // Рисуем прогресс полукруга
        canvas.drawArc(rect, 150f, 240f * progress, false, progressPaint)

        // Рисуем текст с процентами (с одним десятичным знаком)
        val progressPercent = progress * 100
        val text = String.format("%.1f%%", progressPercent) // Форматируем как 45.3%
        val centerX = width / 3f
        val centerY = height / 2f + textPaint.textSize / 3 // Смещаем текст для центровки
        canvas.drawText(text, centerX, centerY, textPaint)
    }
}