package com.example.nobadhabits

data class TemplateItem(
    val title: String,
    val subtitle: String,
    val imageRes: Int
)
