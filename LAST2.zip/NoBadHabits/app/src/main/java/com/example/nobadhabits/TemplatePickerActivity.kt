package com.example.nobadhabits

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class TemplatePickerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PAGE_INDEX = "EXTRA_PAGE_INDEX"
        const val EXTRA_SELECTED_TEMPLATE = "EXTRA_SELECTED_TEMPLATE"
    }

    private var pageIndex: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_template_picker)

        pageIndex = intent.getIntExtra(EXTRA_PAGE_INDEX, 0)

        val title = findViewById<TextView>(R.id.templatePickerTitle)
        title.text = if (pageIndex == 0) "Выбери цель" else "Выбери избавление"

        findViewById<ImageButton>(R.id.backButton).setOnClickListener { finish() }

        val items = buildTemplateItems()

        val rv = findViewById<RecyclerView>(R.id.templatesRecyclerView)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = TemplateAdapter(items) { selectedTitle ->
            val result = Intent().apply {
                putExtra(EXTRA_SELECTED_TEMPLATE, selectedTitle)
                putExtra(EXTRA_PAGE_INDEX, pageIndex)
            }
            setResult(RESULT_OK, result)
            finish()
        }
    }

    private fun buildTemplateItems(): List<TemplateItem> {

        // ================= ЦЕЛИ =================
        if (pageIndex == 0) {
            return listOf(
                TemplateItem(
                    title = "Спорт",
                    subtitle = "Движение каждый день — основа силы и энергии.",
                    imageRes = R.drawable.egg
                ),
                TemplateItem(
                    title = "Режим сна",
                    subtitle = "Качественный сон = качественная жизнь.",
                    imageRes = R.drawable.avatar_cat
                ),
                TemplateItem(
                    title = "Чтение",
                    subtitle = "Каждая прочитанная страница делает тебя сильнее.",
                    imageRes = R.drawable.bird
                ),
                TemplateItem(
                    title = "Самодисциплина",
                    subtitle = "Делать нужно не когда хочется, а когда важно.",
                    imageRes = R.drawable.avatar_dog
                ),
                TemplateItem(
                    title = "Медитация",
                    subtitle = "Спокойный ум — мощный ум.",
                    imageRes = R.drawable.avatar_default
                ),
                TemplateItem(
                    title = "Фокус и продуктивность",
                    subtitle = "Меньше шума — больше результата.",
                    imageRes = R.drawable.egg
                ),
                TemplateItem(
                    title = "Финансовая дисциплина",
                    subtitle = "Контроль денег = контроль будущего.",
                    imageRes = R.drawable.avatar_cat
                )
            )
        }

        // ================= ИЗБАВЛЕНИЯ =================
        return listOf(
            TemplateItem(
                title = "Видео игры",
                subtitle = "Возьми контроль обратно — ты сильнее привычки.",
                imageRes = R.drawable.egg
            ),
            TemplateItem(
                title = "Курение",
                subtitle = "Каждый день без сигарет — это победа.",
                imageRes = R.drawable.bird
            ),
            TemplateItem(
                title = "Алкоголь",
                subtitle = "Трезвость — это ясность и сила.",
                imageRes = R.drawable.avatar_cat
            ),
            TemplateItem(
                title = "Порно",
                subtitle = "Чистый фокус = больше энергии и уверенности.",
                imageRes = R.drawable.avatar_dog
            ),
            TemplateItem(
                title = "Социальные сети",
                subtitle = "Твоё время — твоя жизнь. Береги его.",
                imageRes = R.drawable.avatar_default
            ),
            TemplateItem(
                title = "Сладости",
                subtitle = "Стабильная энергия важнее быстрых удовольствий.",
                imageRes = R.drawable.egg
            )
        )
    }
}