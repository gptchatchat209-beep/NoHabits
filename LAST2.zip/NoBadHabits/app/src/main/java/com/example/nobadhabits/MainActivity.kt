package com.example.nobadhabits

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.json.JSONArray

class MainActivity : AppCompatActivity() {

    private lateinit var viewPager: ViewPager2
    private val timerList = timerListStatic

    // ✅ два списка: отдельно для каждой страницы
    private val goalsTimers = mutableListOf<TimerItem>()   // page = 0
    private val removeTimers = mutableListOf<TimerItem>()  // page = 1

    // ✅ два адаптера: отдельно для каждой страницы
    private lateinit var goalsAdapter: TimerAdapter
    private lateinit var removeAdapter: TimerAdapter


    private var isCenterAnimating = false


    private lateinit var addButton: FloatingActionButton
    private lateinit var quoteText: TextView
    private lateinit var bottomNavigation: BottomNavigationView
    private lateinit var prefs: SharedPreferences
    private var backPressedTime: Long = 0

    private lateinit var centerCircleButton: android.view.View

    // ✅ Split chooser (две половины)
    private lateinit var splitChooserContainer: androidx.constraintlayout.widget.ConstraintLayout
    private lateinit var cardGoals: View
    private lateinit var cardQuit: View


    private lateinit var leftClickOverlay: View
    private lateinit var rightClickOverlay: View

    companion object {
        val timerListStatic = mutableListOf<TimerItem>()
        private var chooserShownThisSession = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val timerRunnable = object : Runnable {
        override fun run() {
            if (::goalsAdapter.isInitialized && goalsTimers.isNotEmpty()) {
                goalsAdapter.notifyItemRangeChanged(0, goalsTimers.size, TimerAdapter.PAYLOAD_TICK)
            }
            if (::removeAdapter.isInitialized && removeTimers.isNotEmpty()) {
                removeAdapter.notifyItemRangeChanged(0, removeTimers.size, TimerAdapter.PAYLOAD_TICK)
            }
            handler.postDelayed(this, 1000)
        }
    }


    private val quotes = listOf(
        "Начни с малого, но начни сегодня!",
        "Каждый шаг приближает тебя к цели.",
        "Верь в себя, и мир откроется.",
        "Успех — это сумма маленьких усилий.",
        "Делай то, что любишь, и люби то, что делаешь.",
        "Каждая ошибка — это шаг к победе.",
        "Ты сильнее, чем думаешь.",
        "Сегодня — твой шанс изменить всё.",
        "Мечты сбываются у тех, кто действует.",
        "Не жди, создавай свои возможности.",
        "Упорство побеждает любые преграды.",
        "Каждый день — новая возможность.",
        "Ты — автор своей истории.",
        "Маленькие победы ведут к большим.",
        "Двигайся вперёд, даже если медленно.",
        "Вера в себя — первый шаг к успеху.",
        "Сегодня лучше, чем завтра.",
        "Трудности делают нас сильнее.",
        "Делай больше, чем можешь.",
        "Твой потенциал безграничен!"
    )

    fun getGoalsAdapter(): TimerAdapter = goalsAdapter
    fun getRemoveAdapter(): TimerAdapter = removeAdapter

    private val templateLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data ?: return@registerForActivityResult

                val title = data.getStringExtra(TemplatePickerActivity.EXTRA_SELECTED_TEMPLATE) ?: return@registerForActivityResult
                val pageIndex = data.getIntExtra(TemplatePickerActivity.EXTRA_PAGE_INDEX, viewPager.currentItem)

                // ✅ СОЗДАЁМ ТАЙМЕР СРАЗУ (вариант 1)
                val newTimer = TimerItem(
                    taskName = title,
                    page = pageIndex,
                    startTime = System.currentTimeMillis(),
                    isRunning = true
                )

                timerList.add(newTimer)

                if (pageIndex == 0) {
                    goalsTimers.add(newTimer)
                    goalsAdapter.notifyDataSetChanged()
                } else {
                    removeTimers.add(newTimer)
                    removeAdapter.notifyDataSetChanged()
                }

                saveTimers()
            }
        }

    private val detailLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                result.data?.let { data ->
                    val taskName = data.getStringExtra("TASK_NAME") ?: return@let
                    val startTime = data.getLongExtra("START_TIME", 0L)
                    val elapsedTime = data.getLongExtra("ELAPSED_TIME", 0L)
                    val isRunning = data.getBooleanExtra("IS_RUNNING", false)

                    timerList.find { it.taskName == taskName }?.let { timer ->
                        timer.startTime = startTime
                        timer.elapsedTime = elapsedTime
                        timer.isRunning = isRunning

                        goalsAdapter.notifyDataSetChanged()
                        removeAdapter.notifyDataSetChanged()
                        saveTimers()
                    }
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        prefs = getSharedPreferences("timers_prefs", MODE_PRIVATE)

        quoteText = findViewById(R.id.quoteText)
        addButton = findViewById(R.id.addButton)
        viewPager = findViewById(R.id.homeViewPager)
        bottomNavigation = findViewById(R.id.bottomNavigation)
        centerCircleButton = findViewById(R.id.centerCircleButton)

        // ✅ Split chooser view
        splitChooserContainer = findViewById(R.id.splitChooserContainer)
        cardGoals = findViewById(R.id.cardGoals)
        cardQuit = findViewById(R.id.cardQuit)
        leftClickOverlay = findViewById(R.id.leftClickOverlay)
        rightClickOverlay = findViewById(R.id.rightClickOverlay)


        bottomNavigation.selectedItemId = R.id.nav_home
        quoteText.text = "Цитата дня: ${quotes.random()}"

        // ✅ Загружаем таймеры ДО превью, чтобы в половинах уже были задачи
        loadTimers()

        // ✅ Главный адаптер (для обычного режима)
        goalsAdapter = TimerAdapter(
            goalsTimers,
            onItemClick = { timer -> openDetail(timer) },
            onDeleteClick = { timer ->
                timerList.remove(timer)
                goalsTimers.remove(timer)
                goalsAdapter.notifyDataSetChanged()
                saveTimers()
            }
        )

        removeAdapter = TimerAdapter(
            removeTimers,
            onItemClick = { timer -> openDetail(timer) },
            onDeleteClick = { timer ->
                timerList.remove(timer)
                removeTimers.remove(timer)
                removeAdapter.notifyDataSetChanged()
                saveTimers()
            }
        )

        // ✅ ViewPager обычного режима
        viewPager.adapter = HomePagerAdapter(this)

        // Кнопка добавить
        addButton.setOnClickListener {
            val intent = Intent(this, TemplatePickerActivity::class.java).apply {
                putExtra(TemplatePickerActivity.EXTRA_PAGE_INDEX, viewPager.currentItem)
            }
            templateLauncher.launch(intent)
        }


        // Центральная кнопка
        centerCircleButton.setOnClickListener { btn ->
            if (isCenterAnimating) return@setOnClickListener
            isCenterAnimating = true
            btn.isClickable = false

            btn.animate().cancel()
            val startRot = btn.rotation
            val targetRot = startRot + 180f

            btn.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()

            btn.animate()
                .rotation(targetRot)
                .setDuration(280)
                .withEndAction {
                    btn.rotation = ((btn.rotation % 360f) + 360f) % 360f
                    btn.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(120)
                        .withEndAction {
                            isCenterAnimating = false
                            btn.isClickable = true
                        }
                        .start()
                }
                .start()

            val next = if (viewPager.currentItem == 0) 1 else 0
            viewPager.setCurrentItem(next, true)
        }

        // BottomNavigation
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_ranking -> { startActivity(Intent(this, RankingActivity::class.java)); true }
                R.id.nav_rewards -> { startActivity(Intent(this, RewardsActivity::class.java)); true }
                R.id.nav_profile -> { startActivity(Intent(this, ProfileActivity::class.java)); true }
                else -> false
            }
        }

        // ✅ Показ split chooser один раз за запуск
        val alreadyChosen = savedInstanceState?.getBoolean("ALREADY_CHOSEN") ?: false
        if (!chooserShownThisSession && !alreadyChosen) {
            showSplitChooser()
        } else {
            showMainUi()
        }
    }

    private fun openDetail(timer: TimerItem) {
        val intent = Intent(this, TimerDetailActivity::class.java).apply {
            putExtra("TASK_NAME", timer.taskName)
            putExtra("START_TIME", timer.startTime)
            putExtra("ELAPSED_TIME", timer.elapsedTime)
            putExtra("IS_RUNNING", timer.isRunning)
        }
        detailLauncher.launch(intent)
    }

    private fun showSplitChooser() {
        chooserShownThisSession = true

        // прячем обычный интерфейс
        viewPager.visibility = android.view.View.INVISIBLE
        addButton.visibility = android.view.View.INVISIBLE
        bottomNavigation.visibility = android.view.View.INVISIBLE
        centerCircleButton.visibility = android.view.View.INVISIBLE
        quoteText.visibility = android.view.View.INVISIBLE

        // показываем split chooser
        splitChooserContainer.visibility = android.view.View.VISIBLE
        splitChooserContainer.alpha = 1f

        // вставляем превью-фрагменты (они сами заблокируют тач)
        val fm = supportFragmentManager
        if (fm.findFragmentById(R.id.leftPreviewContainer) == null) {
            fm.beginTransaction()
                .replace(R.id.leftPreviewContainer, HomeGoalsFragment.newInstance(preview = true))
                .replace(R.id.rightPreviewContainer, HomeRemoveFragment.newInstance(preview = true))
                .commitNow()
        }

        leftClickOverlay.setOnClickListener { animateChooseSplit(0) }
        rightClickOverlay.setOnClickListener { animateChooseSplit(1) }

    }

    private fun showMainUi() {
        splitChooserContainer.visibility = android.view.View.GONE

        viewPager.visibility = android.view.View.VISIBLE
        addButton.visibility = android.view.View.VISIBLE
        bottomNavigation.visibility = android.view.View.VISIBLE
        centerCircleButton.visibility = android.view.View.VISIBLE
        quoteText.visibility = android.view.View.VISIBLE
    }

    private fun animateChooseSplit(pageIndex: Int) {
        val other = if (pageIndex == 0) cardQuit else cardGoals

        findViewById<View>(R.id.centerDivider).animate().alpha(0f).setDuration(180).start()

        leftClickOverlay.isClickable = false
        rightClickOverlay.isClickable = false

        other.animate().alpha(0f).setDuration(180).start()

        val root = splitChooserContainer
        val cs = androidx.constraintlayout.widget.ConstraintSet()
        cs.clone(root)

        if (pageIndex == 0) {
            cs.constrainPercentWidth(R.id.cardGoals, 1f)
            cs.constrainPercentWidth(R.id.cardQuit, 0f)
        } else {
            cs.constrainPercentWidth(R.id.cardGoals, 0f)
            cs.constrainPercentWidth(R.id.cardQuit, 1f)
        }

        cs.constrainWidth(R.id.centerDivider, 0)


        val transition = androidx.transition.ChangeBounds().apply { duration = 280 }
        androidx.transition.TransitionManager.beginDelayedTransition(root, transition)
        cs.applyTo(root)

        root.postDelayed({
            showMainUi()
            viewPager.setCurrentItem(pageIndex, false)
        }, 320)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("ALREADY_CHOSEN", chooserShownThisSession)
    }

    override fun onResume() {
        super.onResume()
        bottomNavigation.selectedItemId = R.id.nav_home
        handler.removeCallbacks(timerRunnable)
        handler.post(timerRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(timerRunnable)
        saveTimers()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(timerRunnable)
        goalsAdapter.cleanup()
        removeAdapter.cleanup()
    }

    private fun saveTimers() {
        val now = System.currentTimeMillis()
        for (timer in timerList) {
            if (timer.isRunning) {
                timer.elapsedTime += now - timer.startTime
                timer.startTime = now
            }
        }

        val jsonArray = JSONArray()
        for (timer in timerList) jsonArray.put(timer.toJson())
        prefs.edit().putString("timers", jsonArray.toString()).apply()
    }

    private fun loadTimers() {
        val jsonStr = prefs.getString("timers", null)

        timerList.clear()
        goalsTimers.clear()
        removeTimers.clear()

        if (jsonStr.isNullOrEmpty()) return

        val jsonArray = JSONArray(jsonStr)
        val now = System.currentTimeMillis()

        for (i in 0 until jsonArray.length()) {
            val timerJson = jsonArray.getJSONObject(i)
            val timer = TimerItem.fromJson(timerJson)

            if (timer.isRunning) {
                timer.elapsedTime += now - timer.startTime
                timer.startTime = now
            }

            timerList.add(timer)

            // ✅ раскидываем по страницам
            if (timer.page == 0) {
                goalsTimers.add(timer)
            } else {
                removeTimers.add(timer)
            }
        }
    }

    private fun showAddTaskDialog(pageIndex: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_task, null)
        val input = dialogView.findViewById<EditText>(R.id.customTaskInput)
        val list = dialogView.findViewById<ListView>(R.id.templateList)

        val templates = resources.getStringArray(R.array.task_templates)
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, templates)

        list.setOnItemClickListener { _, _, pos, _ -> input.setText(templates[pos]) }

        AlertDialog.Builder(this)
            .setTitle(if (pageIndex == 0) "Новая цель" else "Новое избавление")
            .setView(dialogView)
            .setPositiveButton("Добавить") { _, _ ->
                val name = input.text.toString()
                if (name.isNotEmpty()) {

                    val newTimer = TimerItem(
                        taskName = name,
                        page = pageIndex, // ✅ ВАЖНО: к какой странице относится
                        startTime = System.currentTimeMillis(),
                        isRunning = true
                    )

                    timerList.add(newTimer)

                    if (pageIndex == 0) {
                        goalsTimers.add(newTimer)
                        goalsAdapter.notifyDataSetChanged()
                    } else {
                        removeTimers.add(newTimer)
                        removeAdapter.notifyDataSetChanged()
                    }

                    saveTimers()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Нажмите ещё раз, чтобы свернуть", Toast.LENGTH_SHORT).show()
            backPressedTime = System.currentTimeMillis()
        }
    }
}
